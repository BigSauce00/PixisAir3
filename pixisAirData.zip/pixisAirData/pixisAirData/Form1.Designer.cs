﻿namespace pixisAirData
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.Label cNCDLabel;
            System.Windows.Forms.Label cNNMLabel;
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.dataSet1 = new pixisAirData.DataSet1();
            this.cOUNTRYBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cOUNTRYTableAdapter = new pixisAirData.DataSet1TableAdapters.COUNTRYTableAdapter();
            this.tableAdapterManager = new pixisAirData.DataSet1TableAdapters.TableAdapterManager();
            this.cOUNTRYBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.cOUNTRYBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.cNCDTextBox = new System.Windows.Forms.TextBox();
            this.cNNMTextBox = new System.Windows.Forms.TextBox();
            cNCDLabel = new System.Windows.Forms.Label();
            cNNMLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOUNTRYBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOUNTRYBindingNavigator)).BeginInit();
            this.cOUNTRYBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(64, 149);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Countries";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(275, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(301, 420);
            this.listBox1.TabIndex = 1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cOUNTRYBindingSource
            // 
            this.cOUNTRYBindingSource.DataMember = "COUNTRY";
            this.cOUNTRYBindingSource.DataSource = this.dataSet1;
            // 
            // cOUNTRYTableAdapter
            // 
            this.cOUNTRYTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.COUNTRYTableAdapter = this.cOUNTRYTableAdapter;
            this.tableAdapterManager.UpdateOrder = pixisAirData.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // cOUNTRYBindingNavigator
            // 
            this.cOUNTRYBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.cOUNTRYBindingNavigator.BindingSource = this.cOUNTRYBindingSource;
            this.cOUNTRYBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.cOUNTRYBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.cOUNTRYBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.cOUNTRYBindingNavigatorSaveItem});
            this.cOUNTRYBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.cOUNTRYBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.cOUNTRYBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.cOUNTRYBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.cOUNTRYBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.cOUNTRYBindingNavigator.Name = "cOUNTRYBindingNavigator";
            this.cOUNTRYBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.cOUNTRYBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.cOUNTRYBindingNavigator.TabIndex = 2;
            this.cOUNTRYBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // cOUNTRYBindingNavigatorSaveItem
            // 
            this.cOUNTRYBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cOUNTRYBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("cOUNTRYBindingNavigatorSaveItem.Image")));
            this.cOUNTRYBindingNavigatorSaveItem.Name = "cOUNTRYBindingNavigatorSaveItem";
            this.cOUNTRYBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.cOUNTRYBindingNavigatorSaveItem.Text = "Save Data";
            this.cOUNTRYBindingNavigatorSaveItem.Click += new System.EventHandler(this.cOUNTRYBindingNavigatorSaveItem_Click);
            // 
            // cNCDLabel
            // 
            cNCDLabel.AutoSize = true;
            cNCDLabel.Location = new System.Drawing.Point(40, 29);
            cNCDLabel.Name = "cNCDLabel";
            cNCDLabel.Size = new System.Drawing.Size(40, 13);
            cNCDLabel.TabIndex = 3;
            cNCDLabel.Text = "CNCD:";
            // 
            // cNCDTextBox
            // 
            this.cNCDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cOUNTRYBindingSource, "CNCD", true));
            this.cNCDTextBox.Location = new System.Drawing.Point(86, 26);
            this.cNCDTextBox.Name = "cNCDTextBox";
            this.cNCDTextBox.Size = new System.Drawing.Size(100, 20);
            this.cNCDTextBox.TabIndex = 4;
            // 
            // cNNMLabel
            // 
            cNNMLabel.AutoSize = true;
            cNNMLabel.Location = new System.Drawing.Point(40, 62);
            cNNMLabel.Name = "cNNMLabel";
            cNNMLabel.Size = new System.Drawing.Size(42, 13);
            cNNMLabel.TabIndex = 5;
            cNNMLabel.Text = "CNNM:";
            // 
            // cNNMTextBox
            // 
            this.cNNMTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.cOUNTRYBindingSource, "CNNM", true));
            this.cNNMTextBox.Location = new System.Drawing.Point(88, 59);
            this.cNNMTextBox.Name = "cNNMTextBox";
            this.cNNMTextBox.Size = new System.Drawing.Size(100, 20);
            this.cNNMTextBox.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 452);
            this.Controls.Add(cNNMLabel);
            this.Controls.Add(this.cNNMTextBox);
            this.Controls.Add(cNCDLabel);
            this.Controls.Add(this.cNCDTextBox);
            this.Controls.Add(this.cOUNTRYBindingNavigator);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOUNTRYBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOUNTRYBindingNavigator)).EndInit();
            this.cOUNTRYBindingNavigator.ResumeLayout(false);
            this.cOUNTRYBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource cOUNTRYBindingSource;
        private DataSet1TableAdapters.COUNTRYTableAdapter cOUNTRYTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator cOUNTRYBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton cOUNTRYBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox cNCDTextBox;
        private System.Windows.Forms.TextBox cNNMTextBox;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IBM.Data.DB2.iSeries;

namespace pixisAirData
{
    public partial class Form1 : Form
    {
        iDB2Connection conn;
        iDB2DataAdapter adapter;
        DataSet dataset;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.COUNTRY' table. You can move, or remove it, as needed.
            this.cOUNTRYTableAdapter.Fill(this.dataSet1.COUNTRY);

        }


        private void button1_Click(object sender, EventArgs e)
        {
            String sql;

            try
            {
                conn = new iDB2Connection("DataSource=deathstar.gtc.edu");
                sql = "SELECT * FROM COUNTRY";
                adapter = new iDB2DataAdapter(sql, conn);

                dataset = new DataSet();
                adapter.Fill(dataset);

                listBox1.Items.Clear();
                foreach (DataRow pRow in dataset.Tables[0].Rows)
                    listBox1.Items.Add(pRow[0] + " " + pRow[1]);
                conn.Close();
            }
            catch (Exception ex){
                listBox1.Items.Add(ex.Message);
            }
        }

        private void cOUNTRYBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cOUNTRYBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }
    }
}
